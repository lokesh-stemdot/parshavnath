<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<script>


$(document).on('click', '#selectmember', function(){
   //var checked = $(".bidcheckbox:checked").length;
  //if(checked>0)
  //{
   $("#unselectmember").prop('checked',true);
   $("#selectmember").prop('checked',true);
   $(".bidcheckbox").prop('checked',true);
   $('#selectmember').hide();
   $('#unselectmember').show();
  //}
 });
 
$(document).on('click', '#unselectmember', function(){
   var checked = $(".bidcheckbox:checked").length;
  if(checked>0)
  {
   $("#unselectmember").prop('checked',false);
   $("#selectmember").prop('checked',false);	  
   $(".bidcheckbox").prop('checked',false);
   $('#selectmember').show();
   $('#unselectmember').hide();
  }
 }); 



//Bulk Message confirmation
$(document).on('click','.bulkmsg',function(){
	//var checked = $(".bidcheckbox:checked").length;
	var buttonID =  $(this).attr("id");
	var msgtype = $(this).attr("data-type");
	
	
	var members = [];
     
	if($(this).attr("data-value") != undefined){
			members.push($(this).attr("data-value"));
	}
	
	if(buttonID == 'sendBulk'){
	   $.each($(".bidcheckbox:checked"), function(){          
               members.push($(this).val());
      });
	}
	
	$('#userlist').val(members.join(", "));	 
		 
	 //$('#csv_id').val(0);
	 $('#return_page').val('/operation/bid/');
	 if($('#userlist').val() != ''){
	    $("#confirmbox").modal("show");
	 }else{
		 alert('Select any member');
	 }

}); 


</script>




<section class="dashboard">
    <div class="container-fluid">
        <div class="row">
           <div class="dashboard-left">
              
                <?php $this->load->view('layout/menu'); ?>

           </div>
           

           <div class="dashboard-right">
               <div class="breadcum">
                 <ul class="clearfix">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Operation</a></li>
                    <li class="active">Send Bid</li>
                 </ul>
               </div>
               
               <?php //$this->load->view('layout/quick-option'); ?>
               
               <?php if($this->session->flashdata('msg')){ ?>
               <div id="return_msg">
                       <?php echo $this->session->flashdata('msg'); ?>
                </div>
               <?php } ?>
               <div id="return_msg" style="display:none;"></div>

               <!-- Main Screen -->
               
                <div class="panel-body-box panel-body-box-full">
                  <header class="clearfix">
                 <h1>Message Bid: 
                 <span>
                 <div class="input-field">   
                   <button id="sendBulk"  name="sendBulk" data-type="3" class="bulkmsg orange-btn-color">Send Message</button>	
                 </div>
                 </span>
                 </h1>
               </header>
               <div class="panel-section clearfix">
               
<?php
//echo time();

$current_time  = time();//strtotime(date("h:i:sa"));
//echo '<br/>';
//$bid_time_start = strtotime(date('Y-m-d')." 10:30:01am");
$bid_time_start = strtotime(date('Y-m-d')." 09:00:01am");
// echo '<br/>';
//$bid_end_time = strtotime(date('Y-m-d')." 11:30:00am");
$bid_end_time = strtotime(date('Y-m-d')." 09:50:00am");
$bid_status =  $gridid = '';
//echo '<br/>';
if($current_time>=$bid_time_start && $current_time<=$bid_end_time){
//echo "This is Bid Time";
$gridid = 'datagrid';
//$bid_status = "style='display:block'";
}else{
	echo"<div id='return_msg'>Messaging Time closed or will be open 09:00 AM to 09:50 AM every day.</div>";
	//$bid_status = "style='display:none'";
	$gridid = 'none';

       
}
$gridid = 'datagrid';

?>               
               
               
             
           
                 
        
               <table id="<?php echo $gridid; ?>" <?php echo $bid_status; ?>>
                 <thead>
                   <tr>
                   <th>
                         <input type="checkbox" id="selectmember" />
                         <input type="checkbox" id="unselectmember" style="display:none"/>
                    </th>
                   <th class="site_name">Customer Entity ID</th>
                   <th>Customer Name</th>
                   <th>Action</th>
                   </tr>
                 </thead>
                 <tbody>
                 <?php
                 if(is_array($customers) && count($customers)>0){
                     foreach($customers as $customer){
	              ?>
              
                    <tr role="row" class="odd">
                    <td><input type="checkbox" value="<?php echo $customer['member_id']; ?>"  name="membercheck[]" class="bidcheckbox" id="bidcheckid_<?php echo $customer['member_id']; ?>" /></td>
                    <td class="sorting_1"><?php echo $customer['member_entity_id']; ?></td>
                    <td><?php echo $customer['member_name']; ?></td>
                    
                    <td>
                      
                      <!-- <a href="#" data-type="1" data-value="<?php echo $customer['member_id']; ?>" class="bulkmsg"><i class="fa fa-pencil-square-o"></i> SMS</a>  
                       <a href="#" data-type="2" data-value="<?php echo $customer['member_id']; ?>" class="bulkmsg"><i class="fa fa-trash"></i> Mail</a> -->
                       <a href="#" data-type="3"  data-value="<?php echo $customer['member_id']; ?>" class="bulkmsg"><i class="fa fa-trash"></i> Send Message</a>
                    </td>
                  </tr>
                  <?php
                      }
                    }
                  ?>
               </tbody>
               </table>


               </div>
               </div>
               
               <!-- Main Screen End -->
               
               
           </div>
        </div>
        </div>
        
        
        
      
        

</section>


<?php $this->load->view('layout/confirm-model'); ?>

