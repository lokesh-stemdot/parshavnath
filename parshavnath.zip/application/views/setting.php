<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>





<section class="dashboard">
    <div class="container-fluid">
        <div class="row">
           <div class="dashboard-left">
              
                <?php $this->load->view('layout/menu'); ?>

           </div>

           <div class="dashboard-right">
   <div class="breadcum">
                 <ul class="clearfix">
                    <li><a href="#">Dashboard</a></li>
                 
                    <li><a href="#">Setting</a></li>
                    <li class="active">Message Text</li>
                 </ul>
               </div>
               
               <?php //$this->load->view('layout/quick-option'); ?>
               
               <?php if($this->session->flashdata('msg')){ ?>
               <div id="return_msg">
                       <?php echo $this->session->flashdata('msg'); ?>
                </div>
               <?php } ?>
               <div id="return_msg" style="display:none;"></div>
                 

 <div class="setting panel-body-box panel-body-box-full">
 
    <header>
                 <h1>Message Setting</h1>
               </header>
               
               
                 <div class="panel-section">
                 <?php //echo date_default_timezone_get(); ?>
                 <?php //echo date('Y-m-d h:i:s'); ?>
               
                 
<?php foreach($message as $msg){ ?>
                 <h3><?php echo $msg['type']; ?>:</h3>
                    <div class="row bid-col-3"> 
                      <div class="col-md-3 col-sm-3">
                      
                      <label>Mail Subject:</label>
                        <div class="form-group">
                           
                            <input type="text" maxlength="75"  class="form-control" name="msg_subject" id="<?php echo $msg['id']; ?>_subject" value="<?php echo $msg['subject']; ?>" />
                        </div>
                      </div>
                      
                       <div class="col-md-4 col-sm-4"> 
                       <label>SMS Message:</label>
                        <div class="form-group">
                          
                            <textarea class="form-control" maxlength="160" name="msg_sms" id="<?php echo $msg['id']; ?>_sms" ><?php echo $msg['sms']; ?></textarea>
                        </div>
                      </div>
                      
                      <div class="col-md-5 col-sm-5"> <label>Mail Message:</label>
                        <div class="form-group">
                          
                            <textarea class="form-control" name="msg_mail" id="<?php echo $msg['id']; ?>_message" ><?php echo $msg['message']; ?></textarea>
                        </div>
                        
                        <button name="<?php echo $msg['id']; ?>" id="<?php echo $msg['id']; ?>_save" class="msg_save_btn submit-btn pull-right" value="Save">Save</button>
                      </div>
                    </div>
<?php } ?>
                    
                    
                    <?php
					/*
                $credit = "http://sms.proactivesms.in/smscredit.jsp?user=parpower&password=parpower";

$text =  simplexml_load_file($credit);

echo $text->credit;
echo '<br/>';
echo $text->accountexpdate;
echo '<br/>';
echo $text->balanceexpdate;
*/
?>
                 </div>
               </div>


</div>
</div>
</div>
</section>
























<script>
$(document).ready(function(){

	// update message
	$(".msg_save_btn").click(function(){
	var mid = $(this).attr("name");
	var subject = $('#'+mid+'_subject').val();
	var message = $('#'+mid+'_message').val();
	var sms = $('#'+mid+'_sms').val();
	var mdiv = $('#'+mid+'_msg').val();
	
	if(subject == '' || message == '' || sms == ''){
	  $('#return_msg').html('Error: message field not be blank.');
	  $('#return_msg').attr('style', 'display:block;');
	}
	else{	
    $.ajax({
        url: '<?php echo base_url(); ?>index.php/dashboard/update_message',
        data: ({'mid': mid,'subject':subject,'message':message,'sms':sms,'mdiv':mdiv}),
        dataType: 'json', 
        type: "post",
		context:mdiv,
        success: function(data){
			         if(data.success){
						
						 //$(this).parents('tr').find('.msgup').html(data.msg);
			            $('#return_msg').html(data.msg);
						$('#return_msg').attr('style', 'display:block;');
					    //$('#'+this+'_message').val(data.message);
					    //$('#'+this+'_subject').val(data.subject); 
					 }else{
						  $('#return_msg').html(data.msg);
						  $('#return_msg').attr('style', 'display:block;');
					 }
				   }             
        });
	  }
    });
	
	
	
	
});	
</script>