<?php

// namespace Facebook;
// Autoload the required files

require_once( APPPATH  . 'libraries/facebook/HttpClients/FacebookHttpable.php');
require_once( APPPATH  . 'libraries/facebook/HttpClients/FacebookCurl.php' );
require_once( APPPATH  . 'libraries/facebook/HttpClients/FacebookCurlHttpClient.php' );
require_once( APPPATH  . 'libraries/facebook/Entities/AccessToken.php');
require_once( APPPATH  . 'libraries/facebook/Entities/SignedRequest.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookSession.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookRedirectLoginHelper.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookRequest.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookResponse.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookSDKException.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookRequestException.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookOtherException.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookAuthorizationException.php' );
require_once( APPPATH  . 'libraries/facebook/GraphObject.php' );
require_once( APPPATH  . 'libraries/facebook/GraphSessionInfo.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookRequestException.php' );
require_once( APPPATH  . 'libraries/facebook/FacebookPermissionException.php' );


use Facebook\HttpClients\FacebookHttpable;
use Facebook\HttpClients\FacebookCurl;
use Facebook\HttpClients\FacebookCurlHttpClient;
use Facebook\Entities\AccessToken;
use Facebook\Entities\SignedRequest;
use Facebook\FacebookSession;
use Facebook\FacebookRedirectLoginHelper;
use Facebook\FacebookRequest;
use Facebook\FacebookResponse;
use Facebook\FacebookSDKException;
use Facebook\FacebookRequestException;
use Facebook\FacebookOtherException;
use Facebook\FacebookAuthorizationException;
use Facebook\GraphObject;
use Facebook\GraphSessionInfo;
use Facebook\FacebookPermissionException;


class FacebookLib {

    var $fbsession;
    var $error_status;
    var $error_message;
    var $error_code;
    var $helper;
    //var $redirecturl=APP_URL.'job_posting_ecosystem/plugin/get_fb_token/';



    public function __construct() {
        FacebookSession::setDefaultApplication('898691206877454', '3b70434d7e22ef4a9b74ab9003d68dd3');
		        //$this->helper = new FacebookRedirectLoginHelper( APP_URL.'job_posting_ecosystem/plugin/get_fb_token/' );
        }

    
	/*public function fb_page_post($page_id, $data, $page_token)  {
		        // $this->fbsession = new FacebookSession($page_token);
		         $page_access_token = 'CAACEdEose0cBACOV9pthvGVMpiLAvcWBa2DewFgo8zVWgRhZAUkSKYqdqzRrgpjdyHF5EbwMeLiA3iYkzjKjAM4AKyjiz7MRipvoUZCJD0wrCzfZAej9taPwtsjY4xp0XYkdMMY7ZBoEvp6eILV69Txxv6Bmub0lPiZAm6to9ZAIj4I2VuRxUBQ2F2MoBfhZAvLfWg8q1AZBBwZDZD';
                 $request = new FacebookRequest(
                                        $page_access_token ,'feed','/'.$page_id.'/feed',
                                        array (
                                             'message' => $data['message'],
                                           )
                                         );
                            $response = $request->execute();
                            $graphObject = $response->getGraphObject();
							
							
            }
	*/

    
   public function my_fbpost($data){
	    $page_id = '1427547614124535'; // PHP Page
		$page_access_token = 'CAACEdEose0cBAJ4HVJKdoVv1Yy3ZBIfNzJ2uummzLt359bH8gC2ZAzjvFTCEfyD1uYXCZBVQbaEGWXZAaSUZAxPVkHP92GhHIpkU2RHp1nYHYHNRoFt1hKlX5x44u2kEpfHj2DIty0z9gUT4egLowLtRTm4Ny0DeNBGJZAs1UpxAYiw2OefnENPbo0rT8wf9sBXOZByFIJgZBgZDZD';
		
		//$page_id = '708568835928259'; // Dynamis Digital
		//$page_access_token = 'CAACEdEose0cBAM4R25ErQQN4YsgxXvLBZArCMh94ZAaUtyKVnMtqddjX0cHPwjO9Qhqh27Q6dqmXcdv7rVDMfaCyVBSWEkR7MkVgs5q6Tm7YJjCXjhAFwUTvbTBMHNF6tzs4cZAvD5v5YY8az5x1uFNzz5offhEZCfAewDi95RHJC6xTcU2ocnfxOD2ZCD9YZD';
	    
	    $this->fbsession = new FacebookSession($page_access_token);
		
		try{
		 $request = new FacebookRequest(
                                         $this->fbsession ,'POST','/'.$page_id.'/feed',
                                         array (
                                             'message' =>  $data['message'],
                                           )
                                         );
                            $response = $request->execute();
                            $graphObject = $response->getGraphObject();
        }
	catch(Exception $e){
		
	var_dump($e->getMessage());	
		
	}
		
		
   }
     
	
	 public function fb_post_image_link_album() {
		 $data['album_id'] = '1663380837207877'; // PHP Page
		$page_access_token = 'CAACEdEose0cBAJ4HVJKdoVv1Yy3ZBIfNzJ2uummzLt359bH8gC2ZAzjvFTCEfyD1uYXCZBVQbaEGWXZAaSUZAxPVkHP92GhHIpkU2RHp1nYHYHNRoFt1hKlX5x44u2kEpfHj2DIty0z9gUT4egLowLtRTm4Ny0DeNBGJZAs1UpxAYiw2OefnENPbo0rT8wf9sBXOZByFIJgZBgZDZD';
		
		//$data['album_id'] = '832007533584388'; // Dynamis Digital
		//$page_access_token = 'CAACEdEose0cBAM4R25ErQQN4YsgxXvLBZArCMh94ZAaUtyKVnMtqddjX0cHPwjO9Qhqh27Q6dqmXcdv7rVDMfaCyVBSWEkR7MkVgs5q6Tm7YJjCXjhAFwUTvbTBMHNF6tzs4cZAvD5v5YY8az5x1uFNzz5offhEZCfAewDi95RHJC6xTcU2ocnfxOD2ZCD9YZD';
	    
        $this->fbsession = new FacebookSession($page_access_token);
        try {
            $response = (new FacebookRequest($this->fbsession, 'POST', '/' . $data['album_id'] . '/photos', array(
               // 'source' => new CURLFile($data['link']) ,
			   'source' => new CURLFile('http://www.upshotlive.com/images/brochure-head-image.jpg') ,
               
                'message' => 'ivalue test image',
                //'access_token' => $data['access_token']
				'access_token' => $page_access_token
            )))->execute();

            $link = $response->getGraphObject()->asArray();

            return $this->composeData($link);
            }

        catch(FacebookRequestException $e)
            {
            return $this->composeError($e);
            }
        }    
       
   
    
   /* 
    public function fb_validate_session($fbtoken) {
		
       // if (isset($_SESSION) && isset($_SESSION['user']['fb_token'])) {
		   if (!empty($fbtoken)) {
            $this->fbsession = new FacebookSession($_SESSION['user']['fb_token']);

            try {
                $this->fbsession->validate();
                $this->error_status = false;
                $this->error_message = '';
                $this->error_code = '';
                }

            catch(FacebookRequestException $ex) {
                $this->composeError($ex);
                }

            catch(Exception $ex) {
                $this->composeError($ex);
                }
            }

        else
            {
            $this->error_status = true;
            $this->error_message == "Token not set";
            $this->error_code = 'V0';
            }

        return $this->getError();
        }
*/


/*
    public function get_user() {
        try {
            $request = (new FacebookRequest($this->fbsession, 'GET', '/me'))->execute();

            $user = $request->getGraphObject()->asArray();
            return $this->composeData($user);
            }

        catch(FacebookRequestException $e)
            {
            return $this->composeError($e);
            }
        }
*/
    
    
    
	

/*
    public function fb_post_link($data) {
            try {
                $response = (new FacebookRequest($this->fbsession, 'POST', '/' . $data['page_id'] . '/photos', array(
                    'source' => new CURLFile($data['link']) ,
                    //'source' => '@'.realpath($data['link']) ,
                    'access_token' => $data['access_token'],
                    'message' => $data['message']
                )))->execute();

                $link = $response->getGraphObject()->asArray();

                return $this->composeData($link);
                }

            catch(FacebookRequestException $e)
                {
                return $this->composeError($e);
                }
        }

*/

   }