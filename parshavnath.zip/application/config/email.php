<?php
/*
	$config['useragent'] = 'CodeIgniter';
	$config['protocol'] = 'smtp';
    $config['smtp_host'] = 'mail.parshavnathpower.in'; //change this
    $config['smtp_port'] = '25';
    $config['smtp_user'] = 'info@parshavnathpower.in'; //change this
    $config['smtp_pass'] = '7x871xWD}M#~'; //change this
    $config['mailtype'] = 'html';
    $config['charset'] = 'utf-8';
    $config['wordwrap'] = TRUE;
	$config['validate'] = FALSE;
    $config['newline'] = "\r\n";
*/

	$config['protocol'] = 'smtp';
    $config['smtp_host'] = 'mail.stemdot.com'; //change this
    $config['smtp_port'] = '25';
    $config['smtp_user'] = 'ljain@stemdot.com'; //change this
    $config['smtp_pass'] = 'Lokesh@123$$'; //change this
    $config['mailtype'] = 'html';
    $config['charset'] = 'utf-8';
    $config['wordwrap'] = TRUE;
	$config['validate'] = FALSE;
    $config['newline'] = "\r\n";
	
?>