<?php
//database connection details
$connect = mysql_connect('localhost','root','');

if (!$connect) {
 die('Could not connect to MySQL: ' . mysql_error());
}

//your database name
$cid =mysql_select_db('test',$connect);
?>


<form method="post" enctype="multipart/form-data">

<input type="file" name="uploadcsv" />

<input type="submit" name="import" value="upload" />
</form>


<?php

if(isset($_POST['import'])){
	//$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
	//echo'<pre>';print_r(pathinfo($_FILES['uploadcsv']['name']));
	
  if(pathinfo($_FILES['uploadcsv']['name'],PATHINFO_EXTENSION) == 'csv' && $_FILES['uploadcsv']['size']<=2097152)
     {
		$target_dir = "upload/csv/";
		
        $target_file = $target_dir.basename($_FILES["uploadcsv"]["name"]);
		if(move_uploaded_file($_FILES['uploadcsv']['tmp_name'], $target_file)){
			
			$csv_file = $target_file; 

			if (($handle = fopen($csv_file, "r")) !== FALSE) {
                fgetcsv($handle);   
               while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                     $num = count($data);
                     for ($c=0; $c < $num; $c++) {
                      $col[$c] = $data[$c];
                     }
                     $col1 = $col[0];
                     $col2 = $col[1];

// SQL Query to insert data into DataBase
$query = "INSERT INTO import_data(pid,pname) VALUES('".$col1."','".$col2."')";
$s = mysql_query($query, $connect );
 }
    fclose($handle);
	
	echo'Import successfully';
}
		}else{
			echo 'error to upload';
		}
		
	}else{
		echo'Only csv file can be upload.';
	}
	
}

?>

<table width="50%" border="1" cellpadding="0" cellspacing="0">
<tr>
 <th>#</th>
 <th>pid</th>
 <th>pname</th>
 <th>status</th>
 <th>action</th>
</tr>
<?php
$i = 1;
$query = "select * from import_data";
$r = mysql_query($query, $connect );
if(mysql_num_rows($r)>0){
 while($row = mysql_fetch_array($r)){
	
?>
<tr>
 <td><?php echo $i++; ?></td>
 <td><?php echo $row['pid']; ?></td>
 <td><?php echo $row['pname']; ?></td>
 <td><?php echo $row['status']; ?></td>
 <td>action</th>
</tr>
<?php	
 }
}else{
?>
<tr>
 <th colspan="5">No any record.</th>
</tr>	
<?php	
 }
?>
</table>