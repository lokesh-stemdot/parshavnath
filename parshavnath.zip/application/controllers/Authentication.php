<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()
        {
                parent::__construct();
				$this->load->library('session');
				$this->load->helper('form');
		        $this->load->library('form_validation');
          
        }
	
	public function index()
	{
		 $login_check = $this->session->userdata('login');
	        if(!empty($login_check)){
			  redirect('dashboard/');
		}
		
		$data['page_title']  = 'IFX | Admin Login';
		
	    $this->form_validation->set_rules('user_name', 'Username', 'required');
        $this->form_validation->set_rules('user_password', 'Password', 'required');
	
		if ($this->form_validation->run() === FALSE)
		  {
			  // $this->load->view('layout/header', $data); 
	           $this->load->view('login',$data);
		       //$this->load->view('layout/footer');
		  }
		else{
			
			$username = 'mjain';
			$password = 'mjain';
			
		  $uname  = $this->input->post('user_name', TRUE);
		  $upass  = $this->input->post('user_password', TRUE);
			
			if($username == $uname && $password == $upass){ 
			   $login_session = array(
					 'login'  =>  'success'
				 );
				  $this->session->set_userdata($login_session);
			      redirect('dashboard/');
			}else{
				$this->session->set_flashdata('msg', 'Error: Mistake in username/password'); 
				//$this->load->view('layout/header', $data); 
	            $this->load->view('login',$data);
		        //$this->load->view('layout/footer');
			}
			/*
			   $admin_detail = $this->admin->check_admin();
			 // echo'<pre>';print_r($admin_detail); die();
			   if(is_array($admin_detail)){
				 $register_user_data = array(
					 'admin_id'  =>  $admin_detail[0]['id'],
					 'admin_level'  =>  $admin_detail[0]['level']
				 );
				  $this->session->set_userdata($register_user_data);
				  if($admin_detail[0]['level'] == 'first'){
				     redirect('admin/token/');
				  }else{
					  redirect('admin/dashboard/');
				  }
			   }else{
				    $this->session->set_flashdata('msg', 'Error: Mistake in username/password');
				    redirect('admin/');
			   }*/
		  }
		  
	}
	
	
	
	
	public function logout()
	{   
	    $this->session->sess_destroy();
		redirect('');
		/*$data['page_title']  = 'IFX |  Login';
		$this->load->view('layout/header', $data); 
	    $this->load->view('login');
		$this->load->view('layout/footer');*/
	}
}
