<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Operation extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
        {
                parent::__construct();
				$this->load->library('session');
				$this->load->helper('form');
		        $this->load->library('form_validation');
			//$this->load->library('email');
			$this->load->library('phpmailer');
				$this->load->model('importcsv');
				$this->load->model('members');
				 $login_check = $this->session->userdata('login');
		     if(empty($login_check)){
			   redirect('');
		     }
				
        }
		
		
	public function index()
	{
		redirect(base_url().'index.php/operation/bid/');
	}
	
	
	public function send_csv_msg($type=NULL)
	{
		$data['page_title']  = 'IEX | Operation';
		$this->load->view('layout/header', $data); 
		switch($type){
			case 'noc':
			$csv_type = 3;
			break;
			case 'credit':
			$csv_type = 2;
			break;
		}
		$data['csv_data']  =   $this->importcsv->select_csv_data($csv_type);
		$data['csv_type'] = $csv_type; 
		$this->load->model('setting');
		$data['message']  =   $this->setting->get_message($csv_type); 
	    $this->load->view('send_csv_msg',$data);
		$this->load->view('layout/footer');
		
	}
		 
	
	public function import_csv_data(){
		//$data['page_title']  = 'Ivalue | Operation';
		//$this->load->view('layout/header', $data); 
	    
		$csv_type = $this->input->get_post('csv_type');
		
		$ext = pathinfo($_FILES['uploadcsv']['name'],PATHINFO_EXTENSION);
		
		 $allow_ext = array('csv','CSV');
		
		if(in_array($ext,$allow_ext) && $_FILES['uploadcsv']['size']<=2097152)
     {
		$target_dir = "upload/csv/";
		
        $target_file = $target_dir.$csv_type.'-'.date('Y-m-d').'-'.rand().'-'.basename($_FILES["uploadcsv"]["name"]);
		if(move_uploaded_file($_FILES['uploadcsv']['tmp_name'], $target_file)){
			$csv_file = $target_file; 
			if (($handle = fopen($csv_file, "r")) !== FALSE) {
                fgetcsv($handle);   
               while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
			       {
                     $num = count($data);
                     for ($c=0; $c < $num; $c++) {
                      $col[$c] = $data[$c];
                     }
					 
					 
					$customer = $col[2];
					$value =   ($csv_type == 3)?$col[5]:$col[11];
					 
					 $this->importcsv->save_csv_data($customer,$value,$csv_type);
                   }
				   //die;
               fclose($handle);
             }
			 
            
			 $this->session->set_flashdata('msg', 'Upload: Successfully'); 
		}else{
			 $this->session->set_flashdata('msg', 'Error: To upload.'); 
		}
		
	}else{
		 $this->session->set_flashdata('msg', 'Warning: Only csv file can be upload.'); 
	}
	
	
	switch($csv_type){
			case 3:
			$type = 'noc';
			break;
			case 2:
			$type = 'credit';
			break;
		}
	
	redirect(base_url().'index.php/operation/send_csv_msg/'.$type);
	     //$this->load->view('send_noc',$data);
		//$this->load->view('layout/footer');
		
	}
	
	
	
	public function remove_csv_data(){
		$type = $this->input->get_post('csv_type', TRUE);
		$this->importcsv->remove_temp_csv($type);
		switch($type){
			case 3:
			$csv_type = 'noc';
			break;
			case 2:
			$csv_type = 'credit';
			break;
		}
		$this->session->set_flashdata('msg', 'Success: CSV Data Removed!');
		redirect(base_url().'index.php/operation/send_csv_msg/'.$csv_type);
	}
	
	public function bid()
	{
		 $this->load->model('members');
		 $this->load->model('setting');
		$data['page_title']  = 'IFX | Operation - Send Bid';
		$this->load->view('layout/header', $data);
		$data['customers']  =   $this->members->get_customer();
		$data['message']  =   $this->setting->get_message(1); 
		$data['csv_type'] = 1;
	    $this->load->view('send_bid',$data);
		$this->load->view('layout/footer');
		
	}
	
	
     
   public function sendmsg(){
	   
	   $action_type = $this->input->get_post('msgtype');
		$members = $this->input->get_post('userlist');
		$return_url = $this->input->get_post('return_page');
		
		$message = $this->input->get_post('message');
		$mail_subject =  $this->input->get_post('subject');
		$sms_text =  $this->input->get_post('smstext');
		
		$csv_type =  $this->input->get_post('csvtype');
		
		
		
		$member_ary = explode(',',$members);
		//echo '<pre>';print_r($member_ary);
		//$unique_member = array_unique($member_ary);
		//echo'<pre>';print_r(array_unique($member_ary));die;
		$count = $tmp_csv_id = 0;
		
		
		
		$this->load->model('members');
		
		
		
		
		  $this->form_validation->set_rules('message', 'Message Text', 'required');
		   $this->form_validation->set_rules('userlist', 'Select User', 'required');
		   $this->form_validation->set_rules('smstext', 'SMS Text', 'required');
		  
		  if ($this->form_validation->run() === FALSE){
			 //$this->session->set_flashdata('msg', 'Alert: Required value not found.'); 
			 $data['msg'] = 'Required field not empty.';
		  }else{
		     foreach($member_ary as $member){
			
		     $member_detail = $this->members->get_customer($member);
		  
		 
			 $csv_value = $this->get_csv_value($member_detail[0]['member_entity_id'],$message,$sms_text,$csv_type);
			 
			 if($csv_value['send_status'] == 1){
				 continue;
			 }
			 
			 $message_body =  $csv_value['message_body'];
			 $tmp_csv_id = $csv_value['tmp_csv_id'];
			 $sms_msg = $csv_value['sms_msg'];
		 
		 
		
		  switch($action_type){
			  
			case 'sms':
			$success = $this->sendsms($sms_msg,$member_detail[0]['member_contact'],$member_detail[0]['member_entity_id'],$csv_type,$tmp_csv_id);
			if($success){ 
			  $count++;
			}
			break;
			
			case 'mail':
			$success = $this->sendmail($member_detail[0]['member_email'],$member_detail[0]['member_entity_id'],$mail_subject,$message_body,$csv_type,$tmp_csv_id);
			if($success){ 
			  $count++;
			}
			break;
			
			//case 'both':
			default:
			$success_m = $this->sendmail($member_detail[0]['member_email'],$member_detail[0]['member_entity_id'],$mail_subject,$message_body,$csv_type,$tmp_csv_id);
			$success_s = $this->sendsms($sms_msg,$member_detail[0]['member_contact'],$member_detail[0]['member_entity_id'],$csv_type,$tmp_csv_id);
			if(($success_s + $success_m) == 2){ 
			  $count++;
			}
			break;
			
			
		  } //end of switch
		} // end of forloop
		  }
		//$msg = $count.' Message Deliver.';
		//$this->session->set_flashdata('msg', $msg); 
		//redirect(base_url().'index.php'.$return_url);
		$data['msg'] = 'Message send to '.$count.' members';
		echo json_encode($data);	
	     die;
   }


public function sendsms($message,$contacts,$member_id,$msg_type,$tmp_csv_id){

$this->load->model('report');

$contact = explode(',',$contacts);
$c = $count = 0;
foreach($contact as $mobile){
	if(empty($mobile)){
	  continue;
	}
$xml_data ="<?xml version='1.0'?>
<smslist>
<sms>
<user>".SMS_API_UNAME."</user>
<password>".SMS_API_PASS."</password>
<message>$message</message>
<mobiles>$mobile</mobiles>
<senderid>ENERGY</senderid>
</sms>
</smslist>";
$URL = "http://sms.proactivesms.in/sms/sendsms.jsp?";
$ch = curl_init($URL);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_ENCODING, 'UTF-8');
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/xml'));
curl_setopt($ch, CURLOPT_POSTFIELDS, "$xml_data");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$output = curl_exec($ch);
curl_close($ch);
//print_r($output);

$sms = simplexml_load_string($output);

//if($sms){
if($sms->sms[0]->messageid) {	
     $delivery_id = $sms->sms[0]->messageid; //$s->messageid;
	 $count++;
     $report_id = $this->report->save_report($message,$member_id,$msg_type,$delivery_id,$tmp_csv_id,'sms',$mobile);
  }// if end  
  unset($mobile);
}//end for
	if($count>0){
		return 1;
	}else{
		return 0;
	}			
}

   /*public function sendmail($to,$member_id,$subject,$message,$msg_type,$tmp_csv_id){
	            $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= 'From: <info@parshavnathpower.com>' . "\r\n";
                //$headers .= 'Cc: myboss@example.com' . "\r\n";
				
				$this->load->model('report');
				$message = '<pre  style="font-size:16px; font-weight:bold">'.$message.'</pre>';
				if(mail($to,'Parshavnath: '.$subject,$message,$headers)){
					 $report_id = $this->report->save_report($message,$member_id,$msg_type,NULL,$tmp_csv_id,'mail',$to);
					return 1;
				}else{
					return 0;
				}
   }
   */
   
 /*public function sendmail($to,$member_id,$subject,$message,$msg_type,$tmp_csv_id)
	{
		
		$to = 'lokeshalw@yahoo.com';
		$message = 'test mail';
		$subject = 'test subject';
		$this->load->library('email'); // load email library
		$this->email->initialize($config);
		$this->email->from('ljain@stemdot.com');
		$this->email->to($to);
		//$this->email->cc('test2@gmail.com'); 
		$this->email->subject($subject);
		$this->email->message($message);
		//$this->email->attach('/path/to/file1.png'); // attach file
		//$this->email->attach('/path/to/file2.pdf');
		$this->email->send();
		echo $this->email->print_debugger();
		die;
		//die;
		if ($this->email->send()){
			$this->load->model('report');
			$report_id = $this->report->save_report($message,$member_id,$msg_type,NULL,$tmp_csv_id,'mail',$to);
					return 1;
		}else{
			return 0;
		}	
	}
   */
    public function sendmail($to,$member_id,$subject,$message,$msg_type,$tmp_csv_id)
	{
	  $subject = 'Testing Email';
      $name = 'iCoreThink Technologies';
      $email = 'lokeshalw@yahoo.com';
      $body = "This is body text for test email to combine CodeIgniter and PHPmailer";
	  
	  $this->phpmailer->SMTPDebug = 3; 
		$this->phpmailer->IsSMTP();  // telling the class to use SMTP
		$this->phpmailer->SMTPAuth   = true;  // enable SMTP authentication
		$this->phpmailer->Host  = "mail.stemdot.com"; // set the SMTP server
		$this->phpmailer->Port = 25;                    // set the SMTP port
		$this->phpmailer->Username = "ljain@stemdot.com"; // SMTP account username
		$this->phpmailer->Password = "Lokesh@123$$";
	  
	  
      $this->phpmailer->AddAddress($email);
      $this->phpmailer->IsMail();
      $this->phpmailer->From = 'ljain@stemdot.com';
      $this->phpmailer->FromName = 'Stemdot Solution';
      $this->phpmailer->IsHTML(true);
      $this->phpmailer->Subject = $subject;
      $this->phpmailer->Body = $body;
	  
	  
	  

	  
	  
	  
	  
	  
	  
      if($this->phpmailer->Send()){
		  echo 'sended';
	  }else{
		  echo 'error to send = ';
		  echo  $this->phpmailer->ErrorInfo;
	  }
		die;
	}


  public function get_csv_value($member_entity_id,$message_body,$sms_text,$csv_type){
	   $where = array('csv_type' => $csv_type, 'member_entity_id' => $member_entity_id);
	   $value  =   $this->importcsv->select_csv_value($where);
	   
	   $company =  $this->members->get_customer_detail(array('member_entity_id' => $member_entity_id));
	   
	   $constant = array('[[VALUE]]','[[NAME]]');
	   $replaced = array($value[0]['value'],$company[0]['member_name']);
	   
	  $return['sms_msg'] =  str_replace($constant,$replaced,$sms_text);
	  $return['message_body'] =  str_replace($constant,$replaced,$message_body);
	  $return ['tmp_csv_id'] = $value[0]['id'];
	  $return ['send_status'] = $value[0]['send_status'];
	  return $return;
   }
   








	
} 