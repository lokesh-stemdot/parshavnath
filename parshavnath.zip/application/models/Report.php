<?php

class Report extends CI_Model {

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->database();
        }
		
		
	
		
		
		
		public function save_report($message,$member_id,$sms_type,$delivery_id=NULL,$tmp_csv_id=NULL,$msg_by,$deliver_to){
			/*if(!$tmp_csv_id){
				$tmp_csv_id = 0;
			}*/
			//echo $delivery_id;
			 $data = array(
                         'msg_text' => $message,
                         'msg_date' => date("Y-m-d h:i:s"),
						 'member_id' => $member_id,
						 'message_type' => $sms_type,
						 'csv_tmp_id' => $tmp_csv_id,
						 'sms_delivery_id' => $delivery_id,
						 'msg_by' => $msg_by,
						 'deliver_to' => $deliver_to
                  );
				
                $this->db->insert('iex_sms_report', $data);
				
				if($tmp_csv_id){
				 $this->db->where('id', $tmp_csv_id);
                 $this->db->update('iex_tmp_csv', array('send_status' => 1));
				}
				return $this->db->insert_id();
		}
		
		public function get_send_msg($msg_id=NULL){
			 
			 if(!empty($msg_id)){
				 $where = ' where id = '.$where;
			 }else{
				// $where = 'where 1 ';
			 }
			 
			/* $myquery  = 'SELECT M.*,C.member_name,S.type FROM iex_sms_report as M
			 left join iex_member as C on C.member_entity_id = M.member_id
			  left join iex_message as S on S.id = M.message_type where msg_date like "%'.date('Y-m-d').'%" group by member_id, msg_by order by msg_id desc'; */
			  
			  $myquery  = 'SELECT M.*,GROUP_CONCAT(deliver_to) as sms_deliver_no,GROUP_CONCAT(sms_delivery_id) as sms_deliver_id,C.member_name,S.type FROM iex_sms_report as M
			 left join iex_member as C on C.member_entity_id = M.member_id
			  left join iex_message as S on S.id = M.message_type where msg_date like "%'.date('Y-m-d').'%" group by member_id, message_type,msg_by order by msg_id desc';
			 
			 $reports = $this->db->query($myquery);
			
			 //$query = $this->db->get($tblprefix.'nomine');
             return $reports->result_array();
		}
		/*
		public function select_csv_data($type=NULL){
		  $query = $this->db->query("select csv.*, m.member_name from iex_tmp_csv as csv 
inner join iex_member as m on m.member_entity_id = csv.member_entity_id
where csv.csv_type = '".$type."'");
		 
		 // $query = $this->db->get_where('iex_tmp_csv', array('csv_type' => $type));
		  $admin_data = $query->result_array();
		  if($query->num_rows()>0){
		   return $admin_data;
		  }else {
			  return 0;
		  }
		  	
		}
		
		public function remove_temp_csv($type=NULL){
			$query = $this->db->query("DELETE FROM iex_tmp_csv WHERE csv_type = '".$type."'");
		 
		 
		}
		*/

        
}