<!-- Modal -->
<div id="confirmbox" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <form method="post" action="<?php echo base_url().'index.php/operation/sendmsg/'; ?>" >
    <div class="modal-content">
      <div class="modal-header">
       <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
        <h4 class="modal-title" id="actionmsg">Confirmation!</h4>
      </div>
      <div id="loading"></div>
      <div class="modal-body sms-form" id="detailview">
      <b>Are you sure to send below message to selected user.</b>
      <p id="poperror"></p>
      <p>
         <input type="hidden" id="userlist" name="userlist" required="required"/> 
         <!-- <input type="text" id="csv_id" name="csv_id" /> -->
         <input type="hidden" id="return_page" name="return_page" required="required"/>
         <input type="hidden" id="csv_type" name="csvtype" value="<?php echo $csv_type; ?>" required="required"/>
      </p>
      <div class="form-group">
      <label>Subject *</label>
      <input type="text"  name="subject" maxlength="75" id="subject" required="required" class="form-control" value="<?php echo $message[0]['subject']; ?>" />
      </div>
      
       <div class="form-group">
      <label>SMS Message *</label>
      <textarea  class="form-control" maxlength="160" required="required"  id="smstext" name="smstext"><?php echo $message[0]['sms']; ?></textarea>
      </div>
      
      
      <div class="form-group">
      <label>Mail Message *</label>
      <textarea  class="form-control" required="required"  id="message" name="message"><?php echo $message[0]['message']; ?></textarea>
      </div>
      
      </div>
      <div class="modal-footer">
       <!-- <button type="submit" class="mailbtn btn btn-default" id="confirmyes" data-confirm="confirm"  data-value="">Send</button> -->
        <input type="button"  class="submit-btn send-btn" id="send_mail" data-msgtype = "mail" name="msgtype1" value="Send Mail" /> 
       <input type="button" class="submit-btn send-btn" id="send_sms" data-msgtype = "sms" name="msgtype2" value="Send SMS" />
       <input type="button"  class="submit-btn send-btn" id="send_both" data-msgtype = "both" name="msgtype3" value="Send SMS & Mail" />
       <button type="button" class="submit-btn cancel" data-dismiss="modal">Cancle</button>
      </div>
    </div>
     </form>
  </div>
</div>




<script>


$(document).on('click','.send-btn',function(){


		var userlist = $('#userlist').val();
	    var return_page  = $('#return_page').val();			
		var message = $('#message').val();
		var subject = $('#subject').val();
		var smstext = $('#smstext').val();
		var csvtype = $('#csv_type').val();
		//var csv_id = $('#csv_id').val();
		var msgtype = $(this).attr("data-msgtype");
		
		if(smstext == '' || message == '' || userlist == '' || csvtype == ''){
	  $('#poperror').html('Error: Required field not be empty.');
	  $('#poperror').attr('style', 'color:red;');
	}
	else{	
	    
		$.ajax({
        url: '<?php echo base_url(); ?>index.php/operation/sendmsg/',
        data: ({'userlist':userlist,'csvtype':csvtype,'smstext':smstext,'subject':subject,'message':message,'msgtype':msgtype,'return_page':return_page}),
        dataType: 'json', 
        type: "post",
		//context:<?php echo $message[0]['subject']; ?>,
		 beforeSend: function() {
             $('.modal-footer').attr('style', 'display:none;');
		     $('#detailview').attr('style', 'display:none;');
		     $('#actionmsg').html('Sending...');
		     $('#loading').html("<div style='padding-top:150px;padding-bottom:175px;'><center><img src='<?php echo base_url(); ?>assets/images/sending.gif' /></center></div>");
  },
        success: function(data){
			           $('#return_msg').attr('style', 'display:block;');
			           $("#return_msg").html(data.msg);
					   //var returnmsg =  data.msg;
				   } ,
				   
		complete: function(data){
			           $('.modal-footer').attr('style', 'display:block;');
		               $('#detailview').attr('style', 'display:block;');
		               $('#actionmsg').html('Confirmation!');
		               $('#loading').html('');
					   $('#userlist').val('');	
					   $('#csv_type').val();
		             $('#return_msg').attr('style', 'display:block;');
			         //$("#return_msg").html('Message Deliver Successfully.');
					   //$("#return_msg").html(returnmsg);
		               
					   
			          $("#confirmbox").modal("hide"); 
		        }
		             
        });
	}
		
		
		
		
});
</script>