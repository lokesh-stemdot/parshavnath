<?php /* ?>
<p>
<a href="<?php echo base_url().'index.php/dashboard/'; ?>">Dashboard</a>
   |
<a href="<?php echo base_url().'index.php/dashboard/setting/'; ?>">Setting</a>
   |


<a href="<?php echo base_url().'index.php/operation/bid/'; ?>">Send Bid</a>
   |
   <a href="<?php echo base_url().'index.php/operation/noc/'; ?>">NOC</a>
   |
  <a href="<?php echo base_url().'index.php/customer/'; ?>">Members</a>
   |
   <a href="<?php echo base_url().'index.php/authentication/logout/'; ?>">Logout</a>
   
   
   </p>
   
   <?php */ ?>
   
   
   
     <div id='cssmenu'>
               <ul>
                  <li><a href='<?php echo base_url().'index.php/dashboard/'; ?>'><i class="fa fa-plus"></i> Dashboard</a></li>
                  <li><a href='<?php echo base_url().'index.php/customer/'; ?>'><i class="fa fa-plus"></i> Add/View Customer</a></li>
                  <li class='active has-sub'><a href='#'><i class="fa fa-paper-plane"></i>Operation</a>
                     <ul>
                        <li class='has-sub'><a href='#'>Message/Notification</a>
                           <ul>
                              <li><a href='<?php echo base_url().'index.php/operation/bid/'; ?>'>Send BID</a></li>
                              <li><a href='<?php echo base_url().'index.php/operation/send_csv_msg/noc/'; ?>'>Send NOC</a></li>                              
                              <li><a href='<?php echo base_url().'index.php/operation/send_csv_msg/credit/'; ?>'>Send Credit</a></li>
                           </ul>
                        </li>
                       <!--  <li class='has-sub'><a href='#'>Product 2</a>
                           <ul>
                              <li><a href='#'>Sub Product</a></li>
                              <li><a href='#'>Sub Product</a></li>
                           </ul>
                        </li> -->
                     </ul>
                  </li>
                  <li><a href='<?php echo base_url().'index.php/reports'; ?>'><i class="fa fa-credit-card"></i> Report</a></li>
                  <li><a href='#'><i class="fa fa-cogs"></i> Setting</a>
                    <ul>
                        <li class='has-sub'><a href='<?php echo base_url().'index.php/dashboard/setting/'; ?>'>Message Text</a></li>
                     </ul>   
                  </li>
                  <!-- <li><a href='#'><i class="fa fa-magic"></i> Send Bid</a></li> -->
               </ul>
               </div>