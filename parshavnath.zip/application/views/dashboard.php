<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<section class="dashboard">
    <div class="container-fluid">
        <div class="row">
           <div class="dashboard-left">
		   
               <!--<div id='cssmenu'>
               <ul>
                  <li><a href='#'><i class="fa fa-plus"></i> Add/View Customer</a></li>
                  <li class='active has-sub'><a href='#'><i class="fa fa-paper-plane"></i> Send NOC</a>
                     <ul>
                        <li class='has-sub'><a href='#'>Product 1</a>
                           <ul>
                              <li><a href='#'>Sub Product</a></li>
                              <li><a href='#'>Sub Product</a></li>
                           </ul>
                        </li>
                        <li class='has-sub'><a href='#'>Product 2</a>
                           <ul>
                              <li><a href='#'>Sub Product</a></li>
                              <li><a href='#'>Sub Product</a></li>
                           </ul>
                        </li>
                     </ul>
                  </li>
                  <li><a href='#'><i class="fa fa-credit-card"></i> Send Credit Balance</a></li>
                  <li><a href='#'><i class="fa fa-magic"></i> Send Bid</a></li>
               </ul>
               </div> -->
                <?php $this->load->view('layout/menu'); ?>

           </div>

           <div class="dashboard-right">
               <h1>Welcome to Parshavnath CRM</h1>
               
               <?php $this->load->view('layout/quick-option'); ?>

<?php 
//echo'<pre>';print_r($package_detail);



?>

<?php if($package_detail['credit'] < 5000){ ?>
                <div class="alert-message-box">
               <p><span class="allert-left">Alert :</span> <span class="allert-right">Your sms credit remain only <b><?php echo $package_detail['credit']; ?></b>. Please contact your service provider.</span></p>
             </div>
<?php } ?>

<!-- 
             <div class="alert-message-box-orange">
               <p><span class="allert-left">Alert :</span> <span class="allert-right">Your sms package renew date is <b><?php echo $package_detail['renewdate']; ?></b>. Please contact your service provider.</span></p>
             </div>
               
	-->	

               
           </div>
        </div>
        </div>
</section>