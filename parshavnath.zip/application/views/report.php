<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!---------  -->

<script>
//Bulk Message confirmation
$(document).on('click','.msgDetail',function(){
	//var checked = $(".bidcheckbox:checked").length;
	var msgid =  $(this).attr("data-id");
	var msgtext = $('#sendMsg_'+msgid).html();
	$('#sendMsg').html(msgtext);
	
	$('#mode').html($(this).attr("data-mode"));
	$('#sts').html($(this).attr("data-status"));
	$('#smsdid').html($(this).attr("data-delivery"));
	$('#dto').html($(this).attr("data-dto"));
	$('#mid').html($(this).attr("data-memid"));
	$('#mname').html($(this).attr("data-mname"));
	$('#msgtype').html($(this).attr("data-type"));

	//alert($('#mname').html($(this).attr("data-mname")));
	
	$("#detailBox").modal("show");






/*
 <p><label>Member ID:  </label> <span id="mid"></span></p>
      <p> <label>Member Name: </label> <span id="mname"></span></p>
      <p> <label>Delivery Mode:</label> <span id="mode"></span></p>
      <p><label>Delivery To:</label> <span id="dto"></span></p>
       <label>Message: </label>
      <p id="sendMsg"></p>
      <p><label>SMS Delivery ID:</label><span id="did"></span></p>
	  <p><label>Delivery Status:</label><span id="sts"></span></p>

*/

});
</script>

<section class="dashboard">
    <div class="container-fluid">
        <div class="row">
           <div class="dashboard-left">
              
                <?php $this->load->view('layout/menu'); ?>

           </div>

           <div class="dashboard-right">
             
               
               <div class="breadcum">
                 <ul class="clearfix">
                    <li><a href="#">Dashboard</a></li>
                    <li class="active">Reports</li>
                 </ul>
               </div>
               
               <?php //$this->load->view('layout/quick-option'); ?>
               
               <?php if($this->session->flashdata('msg')){ ?>
               <div id="return_msg">
                       <?php echo $this->session->flashdata('msg'); ?>
                </div>
               <?php } ?>
               <div id="return_msg" style="display:none;"></div>
               <!-- Main Screen -->
               
                <div class="panel-body-box panel-body-box-full">
               <header>
                 <h1>SMS/Mail Reports</h1>
               </header> 
               <div class="panel-section clearfix">
                 
                

               <table id="iexReport">
                 <thead>
                   <tr>
                   <th class="site_name">#</th>
                   <th>Customer Entity ID</th>
                   <th>Customer Name</th>
                   <th>Msg. Type</th>
                   <th>Delivery Mode</th>
                    <th>Delivery Status</th>
                   <th>Action</th>
                   </tr>
                 </thead>
                 <tbody>
                 <?php
                 if(is_array($reports) && count($reports)>0){
					 $i = 1;
                     foreach($reports as $report){
	              ?>
               
                    <tr role="row" class="odd">
                   
                    <td><?php echo $i;//echo $report['msg_date']; ?></td>
                    <td><?php echo $report['member_id']; ?></td>
                    <td><?php echo $report['member_name']; ?></td>
                    <td><?php echo $report['type']; ?></td>
                    <td><?php echo $report['msg_by']; ?></td>
                    <td><?php echo $report['msg_status']; ?></td>
                    <td>
                    <div id="sendMsg_<?php echo $report['msg_id']; ?>" style="display:none;"><?php echo $report['msg_text']; ?></div>
                    <a href="#"  data-mname="<?php echo $report['member_name']; ?>"  data-memid="<?php echo $report['member_id']; ?>" data-mode="<?php echo $report['msg_by']; ?>" data-type="<?php echo $report['type']; ?>" data-status="<?php echo $report['msg_status']; ?>" data-delivery="<?php echo $report['sms_deliver_id']; ?>" data-dto="<?php echo $report['sms_deliver_no']; ?>"  data-id="<?php echo $report['msg_id']; ?>" class="msgDetail">Detail</a>
                    
                    </td>
                  </tr>
                  <?php
				   $i++;
                      }
                    }
                  ?>
               </tbody>
               </table>


               </div>
               </div>
               
               <!-- Main Screen End -->
               
               
           </div>
        </div>
        </div>
        
        
        
        
        
        
        
                
        
        
        
        
</section>


  <script>
  $(function(){
    $("#iexReport").dataTable({
		//"order" :  [[ 0, "desc" ]]
		"order" :  [[ 0, "asc" ]]
/*  "aaData":[
    ["Sitepoint","http://sitepoint.com","Blog","2013-10-15 10:30:00"],
    ["Flippa","http://flippa.com","Marketplace","null"],
    ["99designs","http://99designs.com","Marketplace","null"],
    ["Learnable","http://learnable.com","Online courses","null"],
    ["Rubysource","http://rubysource.com","Blog","2013-01-10 12:00:00"]
  ],
  "aoColumnDefs":[{
        "sTitle":"Site name"
      , "aTargets": [ "site_name" ]
  },{
        "aTargets": [ 1 ]
      , "bSortable": false
      , "mRender": function ( url, type, full )  {
          return  '<a href="'+url+'">' + url + '</a>';
      }
  },{
        "aTargets":[ 3 ]
      , "sType": "date"
      , "mRender": function(date, type, full) {
          return (full[2] == "Blog") 
                    ? new Date(date).toDateString()
                    : "N/A" ;
      }  
  }]*/
});
 $("#datagrid").dataTable({
	 });
  })
</script>




<!-- Detail Modal -->
<div id="detailBox" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
  
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" id="actionmsg">Detail</h4>
      </div>
      <div id="loading"></div>
      <div class="modal-body msgdetail" id="detailview">
   
      <p><label>Member ID:  </label> <span id="mid"></span></p>
      <p> <label>Member Name: </label> <span id="mname"></span></p>
       <p> <label>Message Type:</label> <span id="msgtype"></span></p>
      <p> <label>Delivery Mode:</label> <span id="mode"></span></p>
      <p><label>Delivery To:</label> <span id="dto"></span></p>
       <label>Message: </label>
      <p id="sendMsg"></p>
      <p><label>Delivery Status: </label><span id="sts"></span></p>
      <p><label>SMS Delivery ID: </label><span id="smsdid"></span></p>
       
      
      
     
      
      </div>
      <div class="modal-footer">
       <button type="button" class="submit-btn cancel" data-dismiss="modal">Close</button>
      </div>
    </div>
     
  </div>
</div>

