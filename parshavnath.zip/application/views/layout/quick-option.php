   <div class="right-box-menu">
                   <ul class="clearfix">
                       <li><a href="<?php echo base_url().'index.php/customer/'; ?>"><span><i class="fa fa-plus"></i></span> Add/View Customer</a></li>
                       <li><a href="<?php echo base_url().'index.php/operation/send_csv_msg/noc/'; ?>"><span><i class="fa fa-paper-plane"></i></span> Send NOC</a></li>
                       <li><a href="<?php echo base_url().'index.php/operation/send_csv_msg/credit/'; ?>"><span><i class="fa fa-credit-card"></i></span> Send Credit Balance</a></li>
                       <li><a href="<?php echo base_url().'index.php/operation/bid/'; ?>"><span><i class="fa fa-magic"></i></span> Send Bid</a></li>
                   </ul>
               </div>
