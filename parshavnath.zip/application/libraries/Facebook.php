<?php

// namespace Facebook;
// Autoload the required files

require_once( 'facebook/HttpClients/FacebookHttpable.php');
require_once( 'facebook/HttpClients/FacebookCurl.php' );
require_once( 'facebook/HttpClients/FacebookCurlHttpClient.php' );
require_once( 'facebook/Entities/AccessToken.php');
require_once( 'facebook/Entities/SignedRequest.php' );
require_once( 'facebook/FacebookSession.php' );
require_once( 'facebook/FacebookRedirectLoginHelper.php' );
require_once( 'facebook/FacebookRequest.php' );
require_once( 'facebook/FacebookResponse.php' );
require_once( 'facebook/FacebookSDKException.php' );
require_once( 'facebook/FacebookRequestException.php' );
require_once( 'facebook/FacebookOtherException.php' );
require_once( 'facebook/FacebookAuthorizationException.php' );
require_once( 'facebook/GraphObject.php' );
require_once( 'facebook/GraphSessionInfo.php' );
require_once( 'facebook/FacebookRequestException.php' );
require_once( 'facebook/FacebookPermissionException.php' );





use Facebook\HttpClients\FacebookHttpable;
use Facebook\HttpClients\FacebookCurl;
use Facebook\HttpClients\FacebookCurlHttpClient;
use Facebook\Entities\AccessToken;
use Facebook\Entities\SignedRequest;
use Facebook\FacebookSession;
use Facebook\FacebookRedirectLoginHelper;
use Facebook\FacebookRequest;
use Facebook\FacebookResponse;
use Facebook\FacebookSDKException;
use Facebook\FacebookRequestException;
use Facebook\FacebookOtherException;
use Facebook\FacebookAuthorizationException;
use Facebook\GraphObject;
use Facebook\GraphSessionInfo;
use Facebook\FacebookPermissionException;


class Facebook {

    var $fbsession;
    var $token;
  

    public function __construct() {
        FacebookSession::setDefaultApplication('898691206877454', '3b70434d7e22ef4a9b74ab9003d68dd3');
        }

	public function setToken($token){
		 $this->fbsession = new FacebookSession($token);		
	}
    
    
    public function extendAccessToken(){  
        try {
            $longLiveTokenObj=$this->fbsession->getLongLivedSession();
            return array('error_status'=>false,'token'=>$longLiveTokenObj->getToken());            
        }
        catch(FacebookRequestException $ex) {
               return array('error_status'=>true,'message'=>$ex->getMessage());
                }

        catch(Exception $ex) {
                return array('error_status'=>true,'message'=>$ex->getMessage());
                }
    }
    
    
     public function create_album_image($data) {
        try {
            $response = (new FacebookRequest($this->fbsession, 'POST', '/' . $data['album_id'] . '/photos', array(
                'source' => new CURLFile($data['link']) ,
                //'source' => '@'.realpath($data['link']) ,
                'message' => $data['message'],
                'access_token' => $data['page_token']
            )))->execute();

            $link = $response->getGraphObject()->asArray();

            return $link;
            }

        catch(FacebookRequestException $e)
            {
            return $this->composeError($e);
            }
        }
    
    
    
    public function fb_get_admin_pages() {
            try {
                $request = (new FacebookRequest($this->fbsession, 'GET', '/me/accounts?fields=access_token'))->execute();

                $page = $request->getGraphObject()->asArray();

                return $this->composeData($page);
                }

            catch(FacebookRequestException $e)
                {
                return $e->getMessage();
                }
        }
    

    
    public function composeData($data) {
        $this->error_status = false;
        $this->error_message = '';
        $this->error_code = '';
        $ndata = $this->getError();
        if(count($data)>0){
            $ndata['fb_data'] = $data['data'];
        }
        else{
            $ndata['fb_data'] = '';
        }
        return $ndata;
        }
    
    
    
    public function getError() {
        return array(
            'error_status' => $this->error_status,
            'error_message' => $this->error_message,
            'error_code' => $this->error_code
        );
        }
    
    
}