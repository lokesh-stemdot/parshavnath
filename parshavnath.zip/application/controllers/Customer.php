<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
        {
                parent::__construct();
				$this->load->library('session');
				$this->load->helper('form');
		        $this->load->library('form_validation');
				$this->load->model('members');
				 $login_check = $this->session->userdata('login');
		     if(empty($login_check)){
			   redirect('');
		     }
				
        }
		
		
	public function index()
	{
		$data['page_title']  = 'IFX | Customer';
		$this->load->view('layout/header', $data); 
		$data['customers']  =   $this->members->get_customer();
	    $this->load->view('customer',$data);
		$this->load->view('layout/footer');
	}
	
	
	public function add()
	{
		$data['page_title']  = 'IFX | Add New Customer ';
		$this->load->view('layout/header', $data); 
	    $this->load->view('customer-form');
		$this->load->view('layout/footer');
	}
	
	public function edit($mid=NULL)
	{
		$data['page_title']  = 'IFX | Add New Customer ';
		$this->load->view('layout/header', $data); 
		$data['member_id']  = $mid;
		$data['member_info'] = $this->members->get_customer($mid);
	    $this->load->view('customer-form',$data);
		$this->load->view('layout/footer');
	}
	
	public function delete($mid=NULL)
	{
		$return = $this->members->del_customer();
		$data['success'] = '1';
		echo json_encode($data);	
	}	 
	
	
	public function save(){
	    // Validate and save data 
		  $this->form_validation->set_rules('customer_name', 'Name', 'required');
          $this->form_validation->set_rules('customer_entity_id', 'Customer Entity ID', 'required');
		 // $this->form_validation->set_rules('customer_email', 'Email Address', 'required');
		 // $this->form_validation->set_rules('customer_mobile', 'Mobile Number', 'required');
		  //$this->form_validation->set_rules('customer_company', 'Company Name', 'required');
		  if ($this->form_validation->run() === FALSE){
			 $this->session->set_flashdata('msg', 'Alert: Fill up all mandiatory field.'); 
		  }else{
			   $return_type = $this->members->save_member();
			   if($return_type == 'add'){
		         $this->session->set_flashdata('msg', 'Save: A new member successfull added.');
			     redirect(base_url().'index.php/customer/add');
			   }else{
				   $this->session->set_flashdata('msg', 'Update: Member information update successfully.');
			       redirect(base_url().'index.php/customer/');
			   }
			   
		  }	
		   
	}
		
	
	
}
