   
<!-- <script src="<?php echo base_url(); ?>assets/js/jquery.js"></script> -->
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.placeholder.js"></script>
<script>
$(function () {

    $('.toggle').click(function (event) {
        event.preventDefault();
        var target = $(this).attr('href');
        $(target).toggleClass('hidden show');
    });

});
</script>

<script type="text/javascript">
jQuery(document).ready(function($) {

$("#left-part").height($(document).innerHeight() + 'px'); 

$(window).resize(function() {
$("#left-part").height($(document).innerHeight() + 'px'); 
});


});
</script>


<script type="text/javascript" charset="utf8" src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>
  <script>
  $(function(){
    $("#example").dataTable({
/*  "aaData":[
    ["Sitepoint","http://sitepoint.com","Blog","2013-10-15 10:30:00"],
    ["Flippa","http://flippa.com","Marketplace","null"],
    ["99designs","http://99designs.com","Marketplace","null"],
    ["Learnable","http://learnable.com","Online courses","null"],
    ["Rubysource","http://rubysource.com","Blog","2013-01-10 12:00:00"]
  ],
  "aoColumnDefs":[{
        "sTitle":"Site name"
      , "aTargets": [ "site_name" ]
  },{
        "aTargets": [ 1 ]
      , "bSortable": false
      , "mRender": function ( url, type, full )  {
          return  '<a href="'+url+'">' + url + '</a>';
      }
  },{
        "aTargets":[ 3 ]
      , "sType": "date"
      , "mRender": function(date, type, full) {
          return (full[2] == "Blog") 
                    ? new Date(date).toDateString()
                    : "N/A" ;
      }  
  }]*/
});
 $("#datagrid").dataTable({
	 });
  })
</script>


</body>

</html>

   