<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
    <meta name="format-detection" content="telephone=no">
    <title><?php echo $page_title; ?></title>
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/font-awesome-4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/login.css" rel="stylesheet">
    <script src="<?php echo base_url(); ?>assets/js/html5shiv.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/html5shiv-printshiv.js"></script>
    

</head>

<body>

<div class="login-wrapper">


<?php echo validation_errors();?>

<?php if($this->session->flashdata('msg')){ ?>
<div id="return_msg">
<?php echo $this->session->flashdata('msg'); ?>
</div>
<?php } ?>



    <div class="login-container">
        <div class="logo">
            <a href="index.html"><img src="<?php echo base_url(); ?>assets/images/logo.jpg"></a>
        </div>
        <form  method="post">
                <div class="form-group">
                  <input type="text" placeholder="Username" name="user_name" id="user_name"  class="form-control"  required="required">
                  
                  <span><i class="fa fa-user"></i></span>
                </div>
                <div class="form-group">
                  <input type="Password" placeholder="Password" name="user_password" id="user_password"  class="form-control"  required="required">
                  <span><i class="fa fa-unlock-alt"></i></span>
                </div>

                <div class="checkbox-box">
                    <input type="checkbox" name="one" id="one" />
                    <label for="one">Remember me</label>
                </div>


               
                <input type="submit" name="Login" class="submit" value="Login" />
            </form>
    </div>
</div>
    
<script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.placeholder.js"></script>



</body>

</html>








