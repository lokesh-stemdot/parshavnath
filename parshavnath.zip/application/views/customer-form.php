<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>





<!------------------             --->


<section class="dashboard">
    <div class="container-fluid">
        <div class="row">
           <div class="dashboard-left">
              
                <?php $this->load->view('layout/menu'); ?>

           </div>

           <div class="dashboard-right">
              <div class="breadcum">
                 <ul class="clearfix">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Customer</a></li>
                    <li class="active">Add New Customer</li>
                 </ul>
               </div>
               
               <?php //$this->load->view('layout/quick-option'); ?>
               
               <?php if($this->session->flashdata('msg')){ ?>
               <div id="return_msg">
                       <?php echo $this->session->flashdata('msg'); ?>
                </div>
               <?php } ?>
               <div id="return_msg" style="display:none;"></div>
               <!-- Main Screen -->
               
                <div class="panel-body-box">
               <header>
                 <h1>Add New Customer</h1>
               </header>
               <div class="panel-section">
               
               <?php
//echo '<pre>'; print_r($member_info);

$mname = (!empty($member_info[0]['member_name']))?$member_info[0]['member_name']:'';
$mentity_id = (!empty($member_info[0]['member_entity_id']))?$member_info[0]['member_entity_id']:'';

//$memail = (!empty($member_info[0]['member_email']))?$member_info[0]['member_email']:'';

$memail_ary  = (!empty($member_info[0]['member_email']))?explode(',',$member_info[0]['member_email']):'';
//$memail_ary =   explode(',',$memail);
//list($memail_1,$memail_2,$memail_3,$memail_4) = $memail_ary;



//$mcontact = (!empty($member_info[0]['member_contact']))?$member_info[0]['member_contact']:'';

$mcontact_ary = (!empty($member_info[0]['member_contact']))?explode(',',$member_info[0]['member_contact']):'';
//$mcontact_ary =   explode(',',$mcontact);
//list($mcontact_1,$mcontact_2,$mcontact_3,$mcontact_4) = $mcontact_ary;

$mcompany = (!empty($member_info[0]['member_company']))?$member_info[0]['member_company']:'';
$cid = (!empty($member_info[0]['member_id']))?$member_info[0]['member_id']:'';

?>
          
          
          
          
          
          
               
                 <form method="post" action="<?php echo base_url().'index.php/customer/save/'; ?>">

                    <div class="form-group">
                      <label>Customer Name</label>
                      <input type="text" name="customer_name" value="<?php echo $mname;  ?>" required="required" class="form-control" />
                      <span><i class="fa fa-user"></i></span>
                    </div>

                    <div class="form-group">
                      <label>Customer Email</label>
                     
                    </div>
                    
                     <div class="form-group">
                      
                      <input type="email" name="customer_email_1"value="<?php echo @$memail_ary[0]; ?>"   required="required" class="form-control" />
                      <span class="top-space"><i class="fa fa-envelope-o"></i></span>
                    </div>
                    
                     <div class="form-group">
                      <input type="email" name="customer_email_2"value="<?php echo @$memail_ary[1]; ?>"    class="form-control" />
                      <span class="top-space"><i class="fa fa-envelope-o"></i></span>
                    </div>
                     <div class="form-group">
                     
                      <input type="email" name="customer_email_3"value="<?php echo @$memail_ary[2]; ?>"   class="form-control" />
                      <span class="top-space"><i class="fa fa-envelope-o"></i></span>
                    </div>
                     <div class="form-group">
                      
                      <input type="email" name="customer_email_4"value="<?php echo @@$memail_ary[3]; ?>"    class="form-control" />
                      <span class="top-space"><i class="fa fa-envelope-o"></i></span>
                    </div>

                    <div class="form-group">
                      <label>Customr Mobile</label>
                      
                    </div>
                    <div class="form-group">
                     
                      <input type="text" name="customer_mobile_1"value="<?php echo @$mcontact_ary[0]; ?>" maxlength="10"   required="required" class="form-control" />
                
                      <span class="top-space"><i class="fa fa-mobile"></i></span>
                    </div>
                    <div class="form-group">
                     
                      <input type="text" name="customer_mobile_2"value="<?php echo @$mcontact_ary[1]; ?>"  maxlength="10"   class="form-control" />
                
                      <span class="top-space"><i class="fa fa-mobile"></i></span>
                    </div>
                    <div class="form-group">
                      
                      <input type="text" name="customer_mobile_3"value="<?php echo @$mcontact_ary[2]; ?>"  maxlength="10"    class="form-control" />
                
                      <span class="top-space"><i class="fa fa-mobile"></i></span>
                    </div>
                    <div class="form-group">
                      
                      <input type="text" name="customer_mobile_4"value="<?php echo @$mcontact_ary[3]; ?>"  maxlength="10"   class="form-control" />
                
                      <span class="top-space"><i class="fa fa-mobile"></i></span>
                    </div>
                    
                    
                    
                    
                    <div class="form-group">
                      <label>Cutomer Entity ID</label>
                      <input type="text" name="customer_entity_id" value="<?php echo $mentity_id; ?>" required="required" class="form-control" />
                      <span><i class="fa fa-bars"></i></span>
                    </div>
                    
                    <div class="form-group">
                      <label>Company Name</label>
                      <input type="text" name="customer_company" value="<?php echo $mcompany; ?>"  class="form-control" />
                      <span><i class="fa fa-bars"></i></span>
                    </div>
                    
                      <input type="hidden" name="cid" value="<?php echo $cid; ?>"  />
                      <input type="submit" name="submit" value="save" class="submit-btn" />

                  </form>
               </div>
               </div>
               
               <!-- Main Screen End -->
               
               
           </div>
        </div>
        </div>
</section>









