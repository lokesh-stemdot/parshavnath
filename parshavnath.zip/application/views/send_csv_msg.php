<?php
defined('BASEPATH') OR exit('No direct script access allowed');



$current_time  = time();
$notallow = $bid_status =  $gridid = '';






switch($csv_type){
			case 3:
			$type = 'noc';
			$noc_time_start = strtotime(date('Y-m-d')." 02:00:01pm");
            $noc_end_time = strtotime(date('Y-m-d')." 04:00:01pm");
			
           if($current_time>=$noc_time_start && $current_time<=$noc_end_time){
              $gridid = 'datagrid';
              //$bid_status = "style='display:block'";
              }else{
	          $notallow ="<div id='return_msg'>Messaging time closed or will be open 02:00 PM to 04:00 PM every day.</div>";
	          $bid_status = "style='display:none'";
	          $gridid = 'none';
            }

			break;
			
			case 2:
			$type = 'credit';
			$credit_time_start = strtotime(date('Y-m-d')." 12:30:01pm");
            $credit_end_time = strtotime(date('Y-m-d')." 01:30:01pm");
			
           if($current_time>=$credit_time_start && $current_time<=$credit_end_time){
              $gridid = 'datagrid';
             // $bid_status = "style='display:block'";
              }else{
	          $notallow ="<div id='return_msg'>Messaging time closed or will be open 12:30 PM to 01:30 PM every day.</div>";
	          $bid_status = "style='display:none'";
	          $gridid = 'none';
                    
            }
			break;
		}
?>
<script>

 $(document).on('click','#csvDel',function(){ 
				 if(confirm("Are you sure to remove current csv data!")){
					 return true;
				 }else{
					 return false;
				 }
});	
/*
$(document).on('click','#unselectmember',function(){ 
      var checked = $(".bidcheckbox:checked").length;
				if(checked){ 
  $('.bidcheckbox').attr("checked", false);
  $('#unselectmember').attr("id", 'selectmember');	
				}
});	
*/

$(document).on('click', '#selectmember', function(){
   //var checked = $(".bidcheckbox:checked").length;
  //if(checked>0)
  //{
   $("#unselectmember").prop('checked',true);
   $("#selectmember").prop('checked',true);
   $(".bidcheckbox").prop('checked',true);
   $('#selectmember').hide();
   $('#unselectmember').show();
  //}
 });
 
$(document).on('click', '#unselectmember', function(){
   var checked = $(".bidcheckbox:checked").length;
  if(checked>0)
  {
   $("#unselectmember").prop('checked',false);
   $("#selectmember").prop('checked',false);	  
   $(".bidcheckbox").prop('checked',false);
   $('#selectmember').show();
   $('#unselectmember').hide();
  }
 }); 



//Bulk Message confirmation
$(document).on('click','.bulkmsg',function(){
	//var checked = $(".bidcheckbox:checked").length;
	//sendBulk
	
	var buttonID =  $(this).attr("id");
	var msgtype = $(this).attr("data-type");
	
	var members = [];
     
	if($(this).attr("data-value") != undefined){
			members.push($(this).attr("data-value"));
	}
	
	if(buttonID == 'sendBulk'){
    	$.each($(".bidcheckbox:checked"), function(){          
               members.push($(this).val());
      });
	}
	
	$('#userlist').val(members.join(", "));	 
		 
	 //$('#msgtype').val(msgtype);
	 $('#return_page').val('/operation/send_csv_msg/<?php echo $type; ?>');
	 if($('#userlist').val() != ''){
	    $("#confirmbox").modal("show");
	 }else{
		 alert('Select any member');
	 }

}); 



</script>



<section class="dashboard">
    <div class="container-fluid">
        <div class="row">
           <div class="dashboard-left">
              
                <?php $this->load->view('layout/menu'); ?>

           </div>
           
           
           
           
           
           
           
           
          
           
           
           
           
           
           
           
           

           <div class="dashboard-right">
               <div class="breadcum">
                 <ul class="clearfix">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Operation</a></li>
                    <li class="active">Send <?php echo $type; ?></li>
                 </ul>
                 <?php //echo'my ip '.$_SERVER['REMOTE_ADDR']; ?>
               </div>
               
               <?php //$this->load->view('layout/quick-option'); ?>
               
               <?php if($this->session->flashdata('msg')){ ?>
               <div id="return_msg">
                       <?php echo $this->session->flashdata('msg'); ?>
                </div>
               <?php } ?>
               <div id="return_msg" style="display:none;"></div>

               <!-- Main Screen -->
               
                <div class="panel-body-box panel-body-box-full">
               <!-- <header>
                 <h1><span><a href="#">Add New Customer</a></span></h1>
               </header> -->
               
               
               
               
                <header class="clearfix">
                 <h1>Send <?php echo $type; ?> Messages: 
                 
                  <span style="margin-left:10px;">
                 <div class="input-field"> 
                 <button id="sendBulk" name="sendBulk"  data-type="3" class="bulkmsg orange-btn-color">Send Message</button>
                 </div></span>
                
                  <span>
                 <div class="input-field">   
                  
                   
                   <?php if(is_array($csv_data) && count($csv_data)>0){ ?>
                   
                   
                   <form method="post" action="<?php echo base_url(); ?>index.php/operation/remove_csv_data/" enctype="multipart/form-data" >
<input type="hidden" name="csv_type" value="<?php echo $csv_type; ?>" />
<input type="submit" name="delete" value="Remove CSV Data" id="csvDel" />
</form>

                   
                   <?php } else{ ?>
                   
                   
                   <form method="post" action="<?php echo base_url(); ?>index.php/operation/import_csv_data/" enctype="multipart/form-data">
<span class="custom-file-upload"><input type="file" id="file" name="uploadcsv" /></span>
<input type="hidden" name="csv_type"value="<?php echo $csv_type; ?>" />
<input type="submit" name="import" value="upload" />
</form>

                   <?php } ?>
                   
                 
                   
                   
                 </div>
                  
                 </span>
                 
              
                
    
               </header>
               
               
               
               
               <div class="panel-section clearfix">
               
               
               
               
               
               <?php echo @$notallow; ?>
               

               
               
               
               

               <table id="<?php echo $gridid; ?>" <?php echo $bid_status; ?>>
                 <thead>
                   <tr>
                   <th>
                         <input type="checkbox" id="selectmember" />
                         <input type="checkbox" id="unselectmember" style="display:none"/>
                    </th>
                   <th class="site_name">Customer Entity ID</th>
                   <th>Customer Name</th>
                   <th>Value</th>
                   <th>Action</th>
                   </tr>
                 </thead>
                 <tbody>
                 <?php
				 
				 //echo'<pre>'; print_r($csv_data);
                 if(is_array($csv_data) && count($csv_data)>0){
                     foreach($csv_data as $data){
	              ?>
               <!--            
                <tr role="row" class="odd">
                    <td class="sorting_1">N2RJOPPP0001</td>
                    <td>Mangla ISPAT Ltd.</td>
                    <td><a href="#"><i class="fa fa-pencil-square-o"></i></a>  <a href="#"><i class="fa fa-trash"></i></a></td>
                  </tr>
                   -->
                   
                   <tr role="row" class="odd">
                    <td><input type="checkbox" value="<?php echo $data['member_id']; ?>" name="membercheck[]" class="bidcheckbox" 
                    id="bidcheckid_<?php echo $data['member_id']; ?>" /></td>
                     <td class="sorting_1"><?php  echo $data['member_entity_id']; ?></td>
                    <td><?php  echo $data['member_name']; ?></td>
                    
                     <td><?php  echo $data['value']; ?></td>
                    
                    
                    
                    <td>
                      
                      <!-- <a href="#" data-type="1" data-value="<?php echo $customer['member_id']; ?>" class="bulkmsg"><i class="fa fa-pencil-square-o"></i> SMS</a>  
                       <a href="#" data-type="2" data-value="<?php echo $customer['member_id']; ?>" class="bulkmsg"><i class="fa fa-trash"></i> Mail</a>--> 
                       <a href="#" data-type="3" data-value="<?php echo $data['member_id']; ?>" class="bulkmsg"><i class="fa fa-trash"></i> Send Message</a>
                    </td>
                  </tr>
                  <?php
                      }
                    }else{
					}
                  ?>
               </tbody>
               </table>


               </div>
               </div>
               
               <!-- Main Screen End -->
               
               
           </div>
        </div>
        </div>
        
        
        
      
        

</section>

<script>
  //Reference: 
  //http://www.onextrapixel.com/2012/12/10/how-to-create-a-custom-file-input-with-jquery-css3-and-php/
  ;(function($) {

        // Browser supports HTML5 multiple file?
        var multipleSupport = typeof $('<input/>')[0].multiple !== 'undefined',
            isIE = /msie/i.test( navigator.userAgent );

        $.fn.customFile = function() {

          return this.each(function() {

            var $file = $(this).addClass('custom-file-upload-hidden'), // the original file input
                $wrap = $('<div class="file-upload-wrapper">'),
                $input = $('<input type="text" class="file-upload-input" />'),
                // Button that will be used in non-IE browsers
                $button = $('<button type="button" class="file-upload-button">Import CSV</button>'),
                // Hack for IE
                $label = $('<label class="file-upload-button" for="'+ $file[0].id +'">Select a File</label>');

            // Hide by shifting to the left so we
            // can still trigger events
            $file.css({
              position: 'absolute',
              left: '-9999px'
            });

            $wrap.insertAfter( $file )
              .append( $file, $input, ( isIE ? $label : $button ) );

            // Prevent focus
            $file.attr('tabIndex', -1);
            $button.attr('tabIndex', -1);

            $button.click(function () {
              $file.focus().click(); // Open dialog
            });

            $file.change(function() {

              var files = [], fileArr, filename;

              // If multiple is supported then extract
              // all filenames from the file array
              if ( multipleSupport ) {
                fileArr = $file[0].files;
                for ( var i = 0, len = fileArr.length; i < len; i++ ) {
                  files.push( fileArr[i].name );
                }
                filename = files.join(', ');

              // If not supported then just take the value
              // and remove the path to just show the filename
              } else {
                filename = $file.val().split('\\').pop();
              }

              $input.val( filename ) // Set the value
                .attr('title', filename) // Show filename in title tootlip
                .focus(); // Regain focus

            });

            $input.on({
              blur: function() { $file.trigger('blur'); },
              keydown: function( e ) {
                if ( e.which === 13 ) { // Enter
                  if ( !isIE ) { $file.trigger('click'); }
                } else if ( e.which === 8 || e.which === 46 ) { // Backspace & Del
                  // On some browsers the value is read-only
                  // with this trick we remove the old input and add
                  // a clean clone with all the original events attached
                  $file.replaceWith( $file = $file.clone( true ) );
                  $file.trigger('change');
                  $input.val('');
                } else if ( e.which === 9 ){ // TAB
                  return;
                } else { // All other keys
                  return false;
                }
              }
            });

          });

        };

        // Old browser fallback
        if ( !multipleSupport ) {
          $( document ).on('change', 'input.customfile', function() {

            var $this = $(this),
                // Create a unique ID so we
                // can attach the label to the input
                uniqId = 'customfile_'+ (new Date()).getTime(),
                $wrap = $this.parent(),

                // Filter empty input
                $inputs = $wrap.siblings().find('.file-upload-input')
                  .filter(function(){ return !this.value }),

                $file = $('<input type="file" id="'+ uniqId +'" name="'+ $this.attr('name') +'"/>');

            // 1ms timeout so it runs after all other events
            // that modify the value have triggered
            setTimeout(function() {
              // Add a new input
              if ( $this.val() ) {
                // Check for empty fields to prevent
                // creating new inputs when changing files
                if ( !$inputs.length ) {
                  $wrap.after( $file );
                  $file.customFile();
                }
              // Remove and reorganize inputs
              } else {
                $inputs.parent().remove();
                // Move the input so it's always last on the list
                $wrap.appendTo( $wrap.parent() );
                $wrap.find('input').focus();
              }
            }, 1);

          });
        }

  }(jQuery));

  $('input[type=file]').customFile();
</script>
<?php $this->load->view('layout/confirm-model'); ?>

