<?php

class Importcsv extends CI_Model {

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->database();
        }
		
		
	 /*  public function check_admin()
        {    
		  $tblprefix = $this->db->dbprefix;
		  $data['username']  = $this->input->post('user_name', TRUE);
		  $data['userpass']  = $this->input->post('user_password', TRUE);
			
		  $query = $this->db->get_where($tblprefix.'admin', array('username' => $data['username'],'password'=>$data['userpass']));
		  
		  $admin_data = $query->result_array();
		 // $admin_detail['id'] = $admin_data[0]['id'];
		  //$admin_detail['level'] = $admin_data[0]['level'];
		  if($query->num_rows()>0){
		   //return $admin_data[0]['id']; 
		   return $admin_data;
		  }else {
			  return 0;
		  }	
			
		} */
		
		
		
		public function save_csv_data($customer,$value,$type){
			 $data = array(
                         'member_entity_id' => $customer,
                         'value' => $value,
						 'csv_type' => $type,
						 'date' => date('Y-m-d')
                  );
				
                $this->db->insert('iex_tmp_csv', $data);
				return $this->db->insert_id();
		}
		
		public function select_csv_data($type=NULL){
			
			$sql = "select csv.*, m.* from iex_tmp_csv as csv 
inner join iex_member as m on m.member_entity_id = csv.member_entity_id
where csv.date = '".date('Y-m-d')."' AND csv.csv_type = '".$type."'";

//echo $sql;
		  $query = $this->db->query($sql);
		 
		 // $query = $this->db->get_where('iex_tmp_csv', array('csv_type' => $type));
		  $admin_data = $query->result_array();
		  if($query->num_rows()>0){
		   return $admin_data;
		  }else {
			  return 0;
		  }
		  	
		}
		
		
		public function select_csv_value($cond){
			
				$sms_type = $cond['csv_type'];
				$entity_id = $cond['member_entity_id'];
				
				$query = "select id, value, send_status from iex_tmp_csv where csv_type = ".$sms_type." AND date = '".date('Y-m-d')."' AND member_entity_id = '".$entity_id."'";
				
			 $query = $this->db->query($query);
		 
		
		  $csv_value = $query->result_array();
		  if($query->num_rows()>0){
		   return $csv_value;
		  }else {
			  return 0;
		  }
			
		}
		
		public function remove_temp_csv($type=NULL){
			$query = $this->db->query("DELETE FROM iex_tmp_csv WHERE csv_type = '".$type."'");
		 
		 
		}
		

        
}