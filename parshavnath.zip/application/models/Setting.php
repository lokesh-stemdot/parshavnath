<?php

class Setting extends CI_Model {

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->database();
        }
		
		
	 
		public function get_message($where = NULL){
			 
			 
			 if(!empty($where)){
				 $where = ' where id = '.$where;
			 }else{
				 $where = 'where 1 ';
			 }
			 
			 $myquery  = 'SELECT * FROM iex_message '.$where;
			 
			 $setting = $this->db->query($myquery);
			
			 //$query = $this->db->get($tblprefix.'nomine');
             return $setting->result_array();
		}
		
		
		public function update_message($subject,$sms_text,$message,$mid){
			 $data = array(
               'subject' => $subject,
			   'message' => $message,
			   'sms' => $sms_text
            );

           $this->db->where('id', $mid);
           $this->db->update('iex_message', $data);
		   
		   $result = $this->get_message($mid);
		   
		   return $result;
		}
		
		/*
		public function save_report($message,$member_id,$sms_type,$delivery_id){
			 $data = array(
                         'sms_text' => $message,
                         'sms_date' => date('Y-m-d'),
						 'sms_member_id' => $member_id,
						 'message_type' => $sms_type,
						 'sms_delivery_id' => $delivery_id
                  );
				
                $this->db->insert('iex_sms_report', $data);
				return $this->db->insert_id();
		}
		*/
        
}