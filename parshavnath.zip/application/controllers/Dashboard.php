<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
        {
                parent::__construct();
				$this->load->library('session');
				$this->load->helper('form');
		                $this->load->library('form_validation');
				
		     //if(empty($this->session->userdata('login'))){
                       $login_check = $this->session->userdata('login');
		     if(empty($login_check)){
			   redirect('');
		     }
        }
		
		
		 
	public function index()
	{
		$data['page_title']  = 'IEX |  Dashboard';
		$this->load->view('layout/header', $data); 
	    $data['package_detail'] = $this->smsPackage();
	    $this->load->view('dashboard',$data);
		$this->load->view('layout/footer');
	}
	
	public function smsPackage(){
		//http://sms.proactivesms.in/smscredit.jsp?user=xxx&password=xxx
		
		
		
		$URL = "http://sms.proactivesms.in/smscredit.jsp?user=".SMS_API_UNAME."&password=".SMS_API_PASS;
$ch = curl_init($URL);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_ENCODING, 'UTF-8');
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/xml'));
//curl_setopt($ch, CURLOPT_POSTFIELDS, "$xml_data");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$output = curl_exec($ch);
curl_close($ch);
//print_r($output);

$sms = simplexml_load_string($output);
		
		$return['credit'] = $sms->credit;
        $return['renewdate'] = $sms->balanceexpdate;
        return $return;		
	}
	
	public function setting()
	{
		
		$data['page_title']  = 'IEX |  Setting';
		$this->load->view('layout/header', $data);
		$this->load->model('setting'); 
		$data['message'] = $this->setting->get_message();
	    $this->load->view('setting',$data);
		$this->load->view('layout/footer');
		
	}
	
	
	public function update_message(){
		
		$this->load->model('setting'); 
		$where = $this->input->get_post('mid', TRUE);
		$subject = $this->input->get_post('subject', TRUE);
		$sms_text = $this->input->get_post('sms', TRUE);
		$message = $this->input->get_post('message', TRUE);
		
		$result = $this->setting->update_message($subject,$sms_text,$message,$where);
		
		//echo '<pre>';print_r($result);
		//die;
		
		if(is_array($result) && count($result)>0){
			$data['success'] = '1';
			$data['msg'] = 'Success: Message Updated.';
			
		}else{
			$data['success'] = '0';
			$data['msg'] = 'Error: To Update Message';
		}
		$data['mdiv']	= $this->input->get_post('mdiv', TRUE);		
		echo json_encode($data);
	}
	
	
}
