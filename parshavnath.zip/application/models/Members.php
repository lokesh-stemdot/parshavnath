<?php

class Members extends CI_Model {

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->database();
        }
		
		
	 
		public function get_customer($where = NULL){
			 
			 
			 if(!empty($where)){
				 $where = ' where member_id = '.$where;
			 }else{
				 $where = 'where 1 ';
			 }
			 
			 $myquery  = 'SELECT * FROM iex_member '.$where;
			 
			 $members = $this->db->query($myquery);
			
			 //$query = $this->db->get($tblprefix.'nomine');
             return $members->result_array();
		}
		
		
		public function save_member(){
			$member_email = $member_contact = array();
			
			for($i=1;$i<=4;$i++){
				$member_email[] = $this->input->post('customer_email_'.$i);
			    $member_contact[] = $this->input->post('customer_mobile_'.$i);
			}
			
	$mails = implode(',',$member_email);
			$contacts = implode(',',$member_contact);
			//echo $contacts;
			//die;
			 $data = array(
                         'member_entity_id' => $this->input->post('customer_entity_id'),
                         'member_name' => $this->input->post('customer_name'),
						 'member_email' => $mails,
						  'member_contact' => $contacts,
						   'member_company' => $this->input->post('customer_company')
					
                  );
				$cid = $this->input->post('cid');
				if($cid){
					$this->db->where('member_id', $cid);
                    $this->db->update('iex_member', $data);
					return "update";
				}else{	
                 $this->db->insert('iex_member', $data);
				  return "add";
				}
				//return $this->db->insert_id();
		}
		
		
		
		public function del_customer(){
			$cid = $this->input->get_post('mid');
		    $this->db->query("DELETE FROM iex_member WHERE member_id = ".$cid);
		    return 1;
		 
		}


        public function get_customer_detail($cond){
			
				
				$entity_id = $cond['member_entity_id'];
				
				$query = "select * from iex_member where  member_entity_id = '".$entity_id."'";
				
			 $query = $this->db->query($query);
		 
		
		  $member_array = $query->result_array();
		  if($query->num_rows()>0){
		   return $member_array;
		  }else {
			  return 0;
		  }
			
		}
        
}