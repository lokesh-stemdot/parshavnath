<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
    <meta name="format-detection" content="telephone=no">
    <title><?php echo $page_title; ?></title>
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/font-awesome-4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/table.css">
    <link href="<?php echo base_url(); ?>assets/css/main.css" rel="stylesheet">
    <script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/html5shiv.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/html5shiv-printshiv.js"></script>
    
</head>

<body>

<header>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-sm-3 logo">
                <a href="#"><img src="<?php echo base_url(); ?>assets/images/logo.jpg"></a>
            </div>
            <div class="col-md-9 col-sm-9 header-left">
               <a href="#credits" class="toggle user-name"><span class="avtar"><img src="<?php echo base_url(); ?>assets/images/avtar.jpg"></span>Welcome, Admin <i class="caret"></i></a>
                <div id="credits" class="hidden">
                <span class="arrow-up"></span>
                     <ul>
                         <li><a href="<?php echo base_url().'index.php/dashboard/setting/'; ?>"><i class="fa fa-cogs"></i> Setting</a></li>
                         <li><a href="#"><i class="fa fa-info-circle"></i> Help</a></li>
                         <li><a href="<?php echo base_url().'index.php/authentication/logout/'; ?>"><i class="fa fa-sign-out"></i> Logout</a></li>
                     </ul>
                </div>
            </div>
        </div>
    </div>
</header>