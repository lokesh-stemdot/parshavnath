<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<script type="text/javascript">

$(document).on('click','.del_mem_btn',function(){ 
  
		var mid = $(this).attr("data-value");
		
		var row = $(this).parents('tr').attr('id');
		
		if(confirm("Are you sure to delete")){
		 
		 $.ajax({
        url: '<?php echo base_url(); ?>index.php/customer/delete',
        data: ({'mid': mid}),
        dataType: 'json', 
        type: "post",
		context:row,
        success: function(data){
			         if(data.success){
						  $('#'+row).hide();
						 $("#return_msg").html('Success: Member Delete Successfully');
						 $('#return_msg').attr('style', 'display:block;');
						
					 }else{
						 $("#return_msg").html('Error: To Delete Member');
						 $('#return_msg').attr('style', 'display:block;');
					 }
				   }             
        });
		
	}
	
});



</script>


<?php /* ?>
<div class="container white-box">
<div class="padd20">

<div class="heading"><h3>Customer</h3></div>

<!--  <a href="authentication/logout/">Logout</a> -->

<div class="col-sm-12 message">

<?php $this->load->view('layout/menu'); ?>

<div id="return_msg">
<?php if($this->session->flashdata('msg')){ ?>
<?php echo $this->session->flashdata('msg'); ?>
<?php } ?>

</div>


 <a href="<?php echo base_url().'index.php/customer/add/'; ?>">Add Member</a>


<p>
<table width="95%" border="1" cellpadding="0" cellspacing="0">
<th>Customer ID</th>
<th>Name</th>
<th>Company</th>
<th>Action</th>
<?php 
//echo'<pre>';
//print_r($csv_data);
if(is_array($customers) && count($customers)>0){
 foreach($customers as $customer){
?>
<tr>
<td><?php echo $customer['member_entity_id']; ?></td>
<td><?php echo $customer['member_name']; ?></td>
<td><?php echo $customer['member_company']; ?></td>
<td>
<a href="<?php echo base_url().'index.php/customer/edit/'.$customer['member_id']; ?>" class="editbtn">Edit</a>

| 

<a href="#" class="del_mem_btn" id="<?php echo $customer['member_id']; ?>_delmember"  data-value="<?php echo $customer['member_id']; ?>">Delete</a>
</td>
</tr>
<?php
 }
}
?>

</table>
</p>

</div>


</div>

</div>



<?php */ ?>








<!---------  -->


<section class="dashboard">
    <div class="container-fluid">
        <div class="row">
           <div class="dashboard-left">
              
                <?php $this->load->view('layout/menu'); ?>

           </div>

           <div class="dashboard-right">
             
               
               <div class="breadcum">
                 <ul class="clearfix">
                    <li><a href="#">Dashboard</a></li>
                    <li class="active">Customer List</li>
                 </ul>
               </div>
               
               <?php //$this->load->view('layout/quick-option'); ?>
               
               <?php if($this->session->flashdata('msg')){ ?>
               <div id="return_msg">
                       <?php echo $this->session->flashdata('msg'); ?>
                </div>
               <?php } ?>
               <div id="return_msg" style="display:none;"></div>
               <!-- Main Screen -->
               
                <div class="panel-body-box panel-body-box-full">
               <header>
                 <h1>Customer List<span><a href="<?php echo base_url().'index.php/customer/add/'; ?>">Add New Customer</a></span></h1>
               </header> 
               <div class="panel-section clearfix">
                 
                

               <table id="example">
                 <thead>
                   <tr>
                   <th class="site_name">Customer Entity ID</th>
                   <th>Customer Name</th>
                   <th>Company Name</th>
                   <th>Action</th>
                   </tr>
                 </thead>
                 <tbody>
                 <?php
                 if(is_array($customers) && count($customers)>0){
                     foreach($customers as $customer){
	              ?>
              
                    <tr role="row" class="odd" id="row_<?php echo $customer['member_id']; ?>">
                    <td class="sorting_1"><?php echo $customer['member_entity_id']; ?></td>
                    <td><?php echo $customer['member_name']; ?></td>
                    <td><?php echo $customer['member_company']; ?></td>
                    <td>
                    <a href="<?php echo base_url().'index.php/customer/edit/'.$customer['member_id']; ?>" title="edit"><i class="fa fa-pencil-square-o"></i> Edit</a>  
                    <a href="#" class="del_mem_btn" id="<?php echo $customer['member_id']; ?>_delmember"  data-value="<?php echo $customer['member_id']; ?>"><i class="fa fa-trash"></i> Delete</a>
                    
                    
                   
                    </td>
                  </tr>
                  <?php
                      }
                    }
                  ?>
               </tbody>
               </table>


               </div>
               </div>
               
               <!-- Main Screen End -->
               
               
           </div>
        </div>
        </div>
        
        
        
        
        
        
        
                
        
        
        
        
</section>









