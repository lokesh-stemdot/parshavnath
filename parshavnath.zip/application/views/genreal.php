<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>



<div class="container white-box">
<div class="padd20">

<div class="heading"><h3>Welcome User!</h3></div>



<div class="col-sm-12 message">
<?php $this->load->view('layout/menu'); ?>




Genreal Page
</div>


</div>

</div>